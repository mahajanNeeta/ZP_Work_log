package com.avics.framework.constants;

public class ScriptConstants {
	public static final String XPATH = "XPATH";
	public static final String ID = "ID";
	public static final String NAME = "NAME";
	public static final String VERIFYLOGO = "VERIFYLOGO";
	public static final String TAGNAME = "TAGNAME";
	public static final String LINKTEXT = "LINKTEXT";
	public static final String CSSSELECTOR = "CSSSELECTOR";
	public static final String PARTIALTESTNAME = "PARTIALTESTNAME";
	public static final String CLASSNAME = "CLASSNAME";

}
