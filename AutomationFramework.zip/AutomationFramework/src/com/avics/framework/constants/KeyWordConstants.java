package com.avics.framework.constants;

public class KeyWordConstants {
	public static final String LAUNCH = "LAUNCH";
	public static final String LOGIN = "LOGIN";
	public static final String VERIFY_IMAGE = "VERIFYIMAGE";
	public static final String ENTER_TEXT = "ENTERTEXT";
	public static final String CLICK_BUTTON = "CLICKBUTTON";
	public static final String CLICK_INFOBUTTON ="CLICKMAININFOBAR";
}
